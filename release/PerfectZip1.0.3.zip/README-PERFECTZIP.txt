PerfectZip 1.0.3 - carte SD Atmosphère + hekate/Nyx (installation carte vierge)
===============================================================================

Pour qui : une console V1 (Erista) et une carte microSD vide (ou que vous
acceptez de vider), sans aucun fichier existant.

Contenu (binaires officiels non modifiés)
  Atmosphère ......... 1.12.1
  hekate / Nyx ....... 6.5.4 / 1.9.4
  hbmenu ............. 3.6.1
  Payload hekate ..... hekate_ctcaer_6.5.4.bin

Démarrage rapide
  1. Formatez la carte en FAT32 (32 Ko de cluster).
  2. Copiez TOUT le contenu de cette archive à la racine de la carte.
  3. Injectez hekate_ctcaer_6.5.4.bin en mode RCM.
  4. hekate s'ouvre : "Launch" -> "Atmosphere (CFW)".
  Le pas-à-pas complet est dans INSTALLATION.txt.

Carte déjà utilisée ?
  Ne la formatez pas : copiez le contenu par-dessus, en acceptant le
  remplacement. Les dossiers emuMMC/ et Nintendo/ et vos sauvegardes sont
  conservés. Sauvegardez bootloader/hekate_ipl.ini si vous aviez des entrées
  personnalisées, il sera remplacé.

Nyx
  Menu complet de hekate (bootloader/sys/nyx.bin + res.pak), avec les
  bibliothèques l4t (bpmpfw, mtc_tbl, sc7*) et les libsys attendues par
  hekate 6.5.4. Non testé sur console dans cet environnement : je ne garantis
  pas "sans bug", seulement que tous les fichiers officiels requis sont
  présents et cohérents.

Pourquoi aucune entrée Omarchy n'est active (erreur BL31 Missing)
  Une entrée L4T exige /switchroot/omarchyswitch/ avec bl31.bin, bl33.bin,
  uImage, initramfs, nx-plat.dtimg et boot.scr. Ces fichiers Switchroot ne
  sont pas distribuables ici et ne sont pas sur la carte. Les activer produit
  exactement :
      "L4T Error: BL31 Missing!  Failed to launch L4T!"
  L'INI Omarchy est donc fourni en .disabled dans bootloader/ini/ avec la
  procédure d'activation (voir bootloader/ini/README.txt).

Ce que ce pack ne contient pas
  - aucun jeu, sauvegarde ou fichier Nintendo ;
  - aucun firmware (utilisez Daybreak avec vos propres fichiers) ;
  - les fichiers de boot Switchroot (bl31.bin, bl33.bin, uImage, ...) ;
  - un système Omarchy/Linux installable : il n'existe pas encore.

Licences et sources : SOURCE.txt et LICENSES/.
