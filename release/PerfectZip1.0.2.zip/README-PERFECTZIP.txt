PerfectZip 1.0.2 - carte SD Atmosphere + hekate/Nyx
===================================================

Contenu (versions officielles, binaires non modifies)
  Atmosphere ......... 1.12.1
  hekate / Nyx ....... 6.5.4 / 1.9.4
  hbmenu ............. 3.6.1
  Payload hekate ..... hekate_ctcaer_6.5.4.bin

Installation
  1. Formatez la carte SD en FAT32 (recommande pour la partition de boot).
  2. Copiez TOUT le contenu de cette archive a la racine de la carte
     (atmosphere/, bootloader/, switch/, hbmenu.nro,
     hekate_ctcaer_6.5.4.bin, README-PERFECTZIP.txt, SOURCE.txt, LICENSES/).
  3. Injectez hekate_ctcaer_6.5.4.bin en mode RCM (TegraRcmGUI, fusee-launcher
     ou votre dongle habituel).
  4. Dans hekate, "Launch" propose :
       - Atmosphere (CFW)     : Atmosphere sur la sysNAND
       - Stock (SYSNAND)      : Horizon OS d'origine
     "More configs" ne propose volontairement aucune entree L4T.

Nyx
  Nyx est le menu de hekate (bootloader/sys/nyx.bin + res.pak). Il est inclus
  en entier, avec les bibliotheques l4t (bpmpfw, mtc_tbl, sc7*) et les libsys
  attendues par hekate 6.5.4. Il n'a pas ete teste sur console ici : je ne
  garantis donc pas "sans bug", seulement que tous les fichiers officiels
  requis sont presents et coherents.

Pourquoi aucune entree Omarchy n'est active (erreur BL31 Missing)
  Une entree L4T exige /switchroot/omarchyswitch/ avec bl31.bin, bl33.bin,
  uImage, initramfs, nx-plat.dtimg et boot.scr. Ces fichiers Switchroot ne
  sont pas distribuables ici et ne sont pas sur la carte. Les activer produit
  exactement :
      "L4T Error: BL31 Missing!  Failed to launch L4T!"
  L'INI Omarchy est donc fourni en .disabled dans bootloader/ini/ avec la
  procedure d'activation (voir bootloader/ini/README.txt). Ce n'est pas un bug
  de l'archive : les fichiers de boot Switchroot et un rootfs Omarchy n'existent
  pas encore.

Ce que ce pack ne contient pas
  - les fichiers de boot Switchroot (bl31.bin, bl33.bin, uImage, ...) ;
  - un systeme Omarchy/Linux installable : il n'existe pas encore ;
  - vos donnees : emuMMC, Nintendo, jeux et sauvegardes ne sont pas inclus.

Licences et sources : SOURCE.txt et LICENSES/.
