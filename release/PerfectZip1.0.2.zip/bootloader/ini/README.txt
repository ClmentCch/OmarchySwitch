OmarchySwitch (L4T) entries — DISABLED ON PURPOSE
=================================================

hekate shows every "*.ini" file of this folder in its "More configs" menu.
The two files here end in ".ini.disabled" on purpose: they are NOT loaded.

Why: an L4T entry only works when the Switchroot boot files exist under
/switchroot/omarchyswitch/ on this same FAT partition:

  bl31.bin  bl33.bin  uImage  initramfs  nx-plat.dtimg  boot.scr

Without them hekate stops with:
  "L4T Error: BL31 Missing!  Failed to launch L4T!"

That is exactly the error seen when the entry was enabled on a card that only
contains Atmosphère. Nothing is broken in the card: the boot files are simply
absent, and the Omarchy root filesystem does not exist yet.

To enable an entry later:
  1. copy the Switchroot boot files into /switchroot/omarchyswitch/
  2. rename "omarchyswitch-erista.ini.disabled" to "omarchyswitch-erista.ini"
  3. keep the same value for id= (OSWITCH) and for the ext4 label of the root
     partition; a mismatch gives "unable to mount root fs"
  4. reboot, open hekate, choose the entry in "More configs"

The debug variant adds a kernel log on the built-in panel (fbconsole=0) and
should only be used for bring-up.
